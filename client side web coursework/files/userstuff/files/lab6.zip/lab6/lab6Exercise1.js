// jde, added 11/11/17, solutions to exercises covering HTML5 exercise

var lab6Exercise1 = (function( ) {
    var placeHolder = "myUnorderedList";

    function ex1a() {
        function init() {
            var where = document.getElementById("myUnorderedList");
            if ( where != null ) {
                where.innerHTML = "Black Orange Pink"; // any old text for the colours
            };
        }

        init();
    }

    function ex1b() {
        getData("colours.txt", true, placeHolder );
    };

    function ex1c() {
        getData("colours.phtml", true, placeHolder);
    };

    function ex1d() {
        getData("colours.xml", false, placeHolder);
    }

    function ex1e() {
        getData("colours.json", true, placeHolder);

    };

    function start( ) {
        var exerciseNo = prompt( "Enter exercise 1. Please choose letter (a -> e):");
        console.log( "Attempting Exercise:" + exerciseNo );
        switch ( exerciseNo ) {
            case "a" :
                ex1a();
                break;
            case "b" :
                ex1b();
                break;
            case "c" :
                ex1c();
                break;
            case "d" :
                ex1d();
                break;
            case "e" :
                ex1e();
                break;
        }
    };

    return {
        start: start
    }
})();


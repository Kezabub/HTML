// JavaScript Document

function getDiceNumber() {
    return Math.floor(Math.random() * 6) + 1;
}

function showDiceValue() {
    var args = showDiceValue.arguments;

    var where = document.getElementById(args[0]);
//	alert( where.childNodes.length );
    if (args[1] == 'true') { // delete current contents of args[ 0 ]
        for (i = 0; i < where.childNodes.length; i++) {
            var aNode = where.childNodes[i];
            where.removeChild(aNode);
        }
    }
    var dieValue = getDiceNumber();
    if (args[2] == 'image') { // then want images
        var picName = './images/dice' + dieValue + '.jpg';
        var imgNode = document.createElement('img');
        imgNode.setAttribute('src', picName);
        imgNode.setAttribute('alt', dieValue);
        where.appendChild(imgNode);
    } else { // just want the die value
        var dieText = document.createTextNode(dieValue);
        where.appendChild(dieText);
    }
}

function showDiceValues(diceType) {
    showDiceValue('dice1', 'true', diceType);
    showDiceValue('dice2', 'true', diceType);
}

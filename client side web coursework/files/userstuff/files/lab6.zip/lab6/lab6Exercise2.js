// jde, added 11/11/17, solutions to exercises covering HTML5 exercise

var lab6Exercise2 = (function( ) {
    var placeHolder = "whereAbouts";

    // Change table style to style 1
    function setStyle1() {
        // obtain references to HTML elements
        var oTable = document.getElementById("table");
        var oTableHead = document.getElementById("tableHead");
        var oTableFirstLine = document.getElementById("tableFirstLine");
        var oTableSecondLine = document.getElementById("tableSecondLine");

        // set styles
        oTable.className = "Table1";
        oTableHead.className = "TableHead1";
        oTableFirstLine.className = "TableContent1";
        oTableSecondLine.className = "TableContent1";
    };

    function setStyle2() {
        // obtain references to HTML elements
        var oTable = document.getElementById("table");
        var oTableHead = document.getElementById("tableHead");
        var oTableFirstLine = document.getElementById("tableFirstLine");
        var oTableSecondLine = document.getElementById("tableSecondLine");

        // set styles
        oTable.className = "Table2";
        oTableHead.className = "TableHead2";
        oTableFirstLine.className = "TableContent2";
        oTableSecondLine.className = "TableContent2";
    }

    function start( doWhat ) {
        var dataType = ( typeof doWhat );
        if ( dataType == "undefined" )
           getData("ex2.phtml", true, placeHolder );
        else {
            if ( dataType == "number") {
                switch ( doWhat ) {
                    case 1 :
                        setStyle1();
                        break;
                    case 2 :
                        setStyle2();
                        break;
                }
            }
        }
    };

    return {
        start: start
    }
})();
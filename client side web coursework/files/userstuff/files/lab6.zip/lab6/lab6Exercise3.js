// jde, added 11/11/17, solutions to exercises covering HTML5 exercise
// this time showing the module revealing pattern

var lab6Exercise3 = (function( ) {
    var placeHolder = "whereAbouts";

    function start( doWhat ) {
        var dataType = ( typeof doWhat );
        if ( dataType == "undefined" )
            getData("ex3.phtml", true, placeHolder );
        else {
            if ( dataType == "number") {
                switch ( doWhat ) {
                    case 1 :
                        getData("ex3b.phtml", true, placeHolder );
                        break;
                }
            }
        }
    }

    return {
        start: start
    }
})();

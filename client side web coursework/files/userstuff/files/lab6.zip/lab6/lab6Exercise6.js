// jde, added 11/11/17, solutions to exercises covering HTML5 exercise
// this time showing the module revealing pattern

var lab6Exercise6 = (function( ) {
    var placeHolder = "navbar";

    function loadJSPage(pageName) {
        // create the XMLHTTPRequest object
        var xhr = (typeof window.XMLHttpRequest == "function") ?
            new XMLHttpRequest() :
            new ActiveXObject("Microsoft.XMLDOM");

        // try to connect to the server
        try {
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var getheadTag = document.getElementsByTagName('head')[0];
                    setjs = document.createElement('script');
                    setjs.setAttribute('type', 'text/javascript');
                    getheadTag.appendChild(setjs);
                    setjs.text = xhr.responseText;
                }
            }
            xhr.open("GET", pageName, true);
            xhr.send(null);
        } catch (e) {
            // display an error in case of failure
            alert("Error connecting to resource:\n" + e.toString());
        }
    }

    // performs a server request and save data in placeholder
    function getData(filename, placeHolder) {
        // create the XMLHTTPRequest object
        var xhr = (typeof window.XMLHttpRequest == "function") ?
            new XMLHttpRequest() :
            new ActiveXObject("Microsoft.XMLDOM");

        // jde, Feb 2001, monolithic code - not to be reproduced - should be broken up into constituent parts
        // try to connect to the server
        try {
            // initiate server request
            xhr.open("GET", filename, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    // continue only if HTTP status is "OK"
                    if (xhr.status == 200) {
                        try {
                            // retrieve the response
                            var response = xhr.responseText;
                            // do something with the response
                            document.getElementById( placeHolder ).innerHTML = response;
                        } catch (e) {
                            // display error message
                            alert("Error reading the response: " + e.toString());
                        }
                    }
                }
            };
            xhr.send(null);
        } catch (e) {
            // display an error in case of failure
            alert("Error connecting to resource:\n" + e.toString());
        }
    }

    function doVisualStuff( ) {
        loadJSPage( 'diceval.js' );
        getData( 'visual.phtml', 'content' );
    }

    function doNonVisualStuff( ) {
        loadJSPage( 'diceval.js' );
        getData( 'nonvisual.phtml', 'content' );
    }

    function start() {
        getData( 'ex6DiceMenu.xml', placeHolder );
    }

    return {
        start: start,
        showVisualDice: doVisualStuff,
        showNonVisualDice: doNonVisualStuff
    }
})();


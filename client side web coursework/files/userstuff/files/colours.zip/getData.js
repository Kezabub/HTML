// create the XMLHTTPRequest object
var xhr = (typeof window.XMLHttpRequest == "function") ?
    new XMLHttpRequest() :
    new ActiveXObject("Microsoft.XMLDOM");

// This is our function to process the returned data
// we can get a variety of data formats
function processTextData(textData, whereAbouts) {
//    alert(data);
    var htmlText = "";
    try {
        var jsonData = JSON.parse(textData);
        if ( typeof jsonData == "object" ) {
            htmlText = "<ul>";
            jsonData.forEach( function (item ) { htmlText += "<li>" + item + "</li>" } );
            htmlText += "</ul>";
        }
    } catch (e) {
        htmlText = textData;
    }
    console.log(whereAbouts, htmlText);
    document.getElementById(whereAbouts).innerHTML = htmlText;
}

function processXMLData( XMLData, whereAouts ) {
    var rootNode = XMLData.documentElement;
    var colours = rootNode.getElementsByTagName("colour");
    console.log(whereAouts, typeof colours);
    var htmlText = "<ul>";
    for (var i=0; i<colours.length; i++) {
        var value = colours[i].childNodes[0].nodeValue;
        htmlText += '<li>' + value + '</li>';
    }
    htmlText += '</ul>';
    document.getElementById( whereAouts ).innerHTML = htmlText;
}

// This is our callback function to process the returned data
function callBack() {
    if (xhr.readyState == 4) {
        if (xhr.status == 200) {
            // this is a quick fix, doesn't use any required options for coursework
            if ( xhr.processMode ) {
                xhr.txtMode == ( true ) ? processTextData(xhr.responseText, xhr.placeHolder) : processXMLData(xhr.responseXML, xhr.placeHolder);
            } else {
                var imageHTML = "<img src='" + xhr.responseText + "' height='320' width'480'>"
                document.getElementById(xhr.placeHolder).innerHTML = imageHTML;
            }
        } else {
            document.getElementById(xhr.placeHolder).innerHTML = "XHR failed:" +
                xhr.statusText + " status:" + xhr.status;
        }
    }
}

function getData(url, txtMode, placeHolder, processMode) {
    // save the type of text, somewhere to place it and whether we have to process the callback or not
    xhr.txtMode = txtMode; // save the type of text and somewhere to place it, to be retrieved for later use
    xhr.placeHolder = placeHolder;
    xhr.processMode = ( processMode === false ) ? false : true;
    xhr.open("GET", url, true);
    xhr.onreadystatechange = callBack;
    xhr.send(null);
}

// jde, added 12/11/17, solutions to exercises covering Week7-8

var lab7Task1 = (function( ) {
    var placeHolder = "myColourList",
        buttonPlaceHolder = "myButtonList";

    function ex1a() {
        getData("colours.txt", true, placeHolder );
    };

    function ex1b() {
        getData("colours.phtml", true, placeHolder);
    };

    function ex1c() {
        getData("colours.xml", false, placeHolder);
    }

    function ex1d() {
        getData("colours.json", true, placeHolder);
    };

    function ex1e() {
        getData("coloursPNG.txt", true, placeHolder, false);
    };

    function buildButtons( options ) {
        var htmlText = "";
        options.forEach( function (option) {
            htmlText += "<button onclick='lab7Task1.run(" + '"' + option + '"' + ")'>Task " + option + "</button><br/>";
        });
        return htmlText;
    }

    function start( ) {
        console.log( "initialising Task 1:" );
        var options = ["a", "b", "c", "d", "e"];
        document.getElementById( buttonPlaceHolder ).innerHTML = buildButtons(options);
    };

    // option should be a-e
    function run( option ) {
        console.log( "Attempting Task1:" + option );
        switch ( option ) {
            case "a" :
                ex1a();
                break;
            case "b" :
                ex1b();
                break;
            case "c" :
                ex1c();
                break;
            case "d" :
                ex1d();
                break;
            case "e" :
                ex1e();
                break;
        }
    };

    return {
        start: start,
        run: run
    }
})();


// Weeks 7&8, jde, Added 25/11/17

// Task 2,

//1
var module = {
    name: "CSWD",
    level: "4",
    lecturer: "Jim Devon"
};

//2
document.writeln(JSON.stringify(module, null, 4));

//3
module.students = [ {name: "Eric Gamma", matricNo: "1911974"},
                    {name: "Richard Helm", matricNo: "2741980"} ];

//4 V1 - OK for small number like this but not good overall
document.writeln( module.students[0].matricNo );
document.writeln( module.students[1].matricNo );
//4 V2 - better for large numbers
module.students.forEach( function (student) { document.writeln( student.matricNo ); })

//5
module.students[0].marks = [25, 18, 35];
module.students[1].marks = [12, 10, 25];

//6
module.totalMarks = function () {

   function add( a, b ) { return a + b; };

   var total = 0;
   this.students.forEach( function (item ) {
      total += item.marks.reduce( add, 0 );
   } );
   return total;
};
document.writeln( module.totalMarks() );

//7
module.students[0].marks.push( 15 );
module.students[1].marks.push( 18 );
document.writeln( module.totalMarks() );

// ============================================

// Task 3.

//1
function module( name, level, lecturer, student1, student2 ) {
  this.name = name;
  this.level = level;
  this.lecturer = lecturer;
  this.students = [{name: student1}, {name:student2}];
}
var cswd = new module("CSWD", "4", "Jim Devon", "Eric Gamma", "Richard Helm");

//2
module.prototype.addMarks = function ( studentNo, marks ) {
   console.log( this.students[ studentNo ] );

   if ( this.students[ studentNo ].marks ) {
      this.students[ studentNo ].marks.push( marks );
   } else {
      // students has no marks so far
      this.students[ studentNo ].marks = [];
      this.students[ studentNo ].marks.push( marks );
   }
};

module.prototype.totalMarks = function ( ) {
   function add( a, b ) { return a + b; };

   var total = 0;
   this.students.forEach( function (student) {
      total += student.marks.reduce( add, 0 );
   } );
   return total;
};

//3
cswd.addMarks(0, 25);
cswd.addMarks(0, 18);
cswd.addMarks(0, 35);
cswd.addMarks(1, 12);
cswd.addMarks(1, 10);
cswd.addMarks(1, 25);

document.writeln(JSON.stringify(cswd, null, 4));
document.writeln("<br />");

document.writeln("marks: " + cswd.totalMarks());
document.writeln("<br />");
